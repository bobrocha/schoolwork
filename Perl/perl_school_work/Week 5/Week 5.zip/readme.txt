1. The "images" directory must be placed in the "htdocs" directory.
2. All image names must be the same as item names for successful retrieval and display.
3. makedata.cgi and showmdse.cgi must be in the "cgi" directory
4. makedata.html must be in the "htdocs" directory